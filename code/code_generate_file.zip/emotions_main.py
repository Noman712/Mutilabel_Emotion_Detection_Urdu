# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 11:42:31 2020

@author: Noman Ashraf
"""

import emotions_ngrams as ed
ds_emotions = ed.EmotionsDataset()




#%% cell

_train_dataset_path = r"C:\Emotion_Urdu\Dataset\train_ds_final.csv"
_test_data_path =  r"C:\Emotion_Urdu\Dataset\test_ds_final.csv"
ds_emotions.Generate_Ngrams(train_dataset_path = _train_dataset_path, test_data_path = _test_data_path ,_ngram_range=(1,1), _max_features=10, words= True)


