# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 11:42:31 2020

@author: Noman Ashraf
"""
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
import csv
from cleantext import clean
import nltk
#nltk.download()
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
import re
from urduhack import normalize
from urduhack.preprocess import normalize_whitespace
from urduhack.normalization import normalize_characters
from urduhack.normalization import digits_space
from urduhack.normalization import punctuations_space
from urduhack.normalization import remove_diacritics
from urduhack.preprocess import remove_accents
class EmotionsDataset:
    
    
    def Clean_Text(text):
        data = clean(text,
        fix_unicode=True,               # fix various unicode errors
        to_ascii=False,                  # transliterate to closest ASCII representation
        lower=False,                     # lowercase text
        no_line_breaks=False,           # fully strip line breaks as opposed to only normalizing them
        no_urls=False,                  # replace all URLs with a special token
        no_emails=False,                # replace all email addresses with a special token
        no_phone_numbers=False,         # replace all phone numbers with a special token
        no_numbers=False,               # replace all numbers with a special token
        no_digits=False,                # replace all digits with a special token
        no_currency_symbols=False,      # replace all currency symbols with a special token
        no_punct=False,                 # fully remove punctuation
        replace_with_url=" ",
        replace_with_email=" ",
        replace_with_phone_number=" ",
        replace_with_number=" ",
        replace_with_digit=" ",
        replace_with_currency_symbol=" ",
        lang="ur"                       # set to 'de' for German special handling
        )
        return data
    
    def RemoveEmoji(text):
        emoji_pattern = re.compile("["
                           u"\U0001F600-\U0001F64F"  # emoticons
                           u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                           u"\U0001F680-\U0001F6FF"  # transport & map symbols
                           u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                           u"\U00002702-\U000027B0"
                           u"\U000024C2-\U0001F251"
                           "]+", flags=re.UNICODE)
        return emoji_pattern.sub(r'', text)    

    def Remove_StopWords(text):     
        stopWords = [line.strip() for line in open(r"C:\Emotion_Urdu\Code\stop_words.txt", encoding="utf8")]
        words = word_tokenize(text)
        wordsFiltered = []
        for w in words:
            if w not in stopWords:
                wordsFiltered.append(w)
        text = ' '.join(wordsFiltered)
        return text
    
    def Normalize_Urdu(text):
        normalized_text = normalize_whitespace(text)
        normalized_text = normalize_characters(normalized_text)
        normalized_text =  normalize(normalized_text)
        normalized_text = punctuations_space(normalized_text)
        normalized_text = remove_accents(normalized_text)
        return normalized_text
    
    
    def Generate_Ngrams(self,  train_dataset_path = "" , test_data_path = "", _ngram_range=(1,1), _max_features=10, words = True):     

        #load train data
        df_train = pd.read_csv(train_dataset_path,usecols=['Sentences','غصہ',"نفرت","خوف","اداسی","حیرت","خوشی"], sep=',', encoding = "utf-8-sig")
        df_train = df_train.drop_duplicates(keep=False)
        
        df_train['Sentences']=df_train['Sentences'].apply(EmotionsDataset.Normalize_Urdu)
        df_train['Sentences']=df_train['Sentences'].apply(EmotionsDataset.RemoveEmoji)
        df_train['Sentences']=df_train['Sentences'].apply(EmotionsDataset.Remove_StopWords)
        
        #with open("/Users/nomanashraf/Documents/Emotions_Analysis_Urdu/Dataset/training_sentences.txt", "w") as outfile:
        #    outfile.write("\n".join(df_train.Sentences.tolist()))
        
        top_words = df_train.Sentences.str.split(expand=True).stack().value_counts()
        
        df_train['word_count'] = df_train['Sentences'].apply(lambda x: len(str(x).split()))
        print(df_train[['Sentences','word_count']].head())
        
        df_train['char_count'] = df_train['Sentences'].str.len() ## this also includes spaces
        print(df_train[['Sentences','char_count']].head())
        
        from collections import Counter
        unique_vocab = len(Counter(" ".join(df_train['Sentences'].str.lower().values.tolist()).split(" ")).items())
        
        df_stat = df_train[['word_count', 'char_count']].agg(['sum','mean'])
        
        
        print("=========== Dataset Train ===========")
        print(df_train.head())
        print(len(df_train))
        print("=========== Dataset Train ===========")
        print("\n")
        
        
        print("=========== Dataset Train Stat ===========")
        print(df_stat)
        print("Unique Vocab:" + str(unique_vocab))
        print(top_words.head(10))
        print("=========== Dataset Train Stat ===========")
        
        
        
        print("=========== Labels ===========")
        comments_labels = df_train[['غصہ',"نفرت","خوف","اداسی","حیرت","خوشی"]]
        print(comments_labels.head())
        print(comments_labels.shape)
        print("=========== Labels ===========")
        print("\n")
        
        
        
        #load test data
        df_test = pd.read_csv(test_data_path,usecols=['Sentences','غصہ',"نفرت","خوف","اداسی","حیرت","خوشی"], sep=',', encoding = "utf-8-sig")
        df_test = df_test.drop_duplicates(keep=False)
        df_test['Sentences']=df_test['Sentences'].apply(EmotionsDataset.Normalize_Urdu)
        df_test['Sentences']=df_test['Sentences'].apply(EmotionsDataset.RemoveEmoji)
        df_test['Sentences']=df_test['Sentences'].apply(EmotionsDataset.Remove_StopWords)
        
        #with open("/Users/nomanashraf/Documents/Emotions_Analysis_Urdu/Dataset/test_sentences.txt", "w") as outfile:
        #    outfile.write("\n".join(df_test.Sentences.tolist()))
        
        
        
        
        top_words_test = df_test.Sentences.str.split(expand=True).stack().value_counts()
        
        df_test['word_count'] = df_test['Sentences'].apply(lambda x: len(str(x).split()))
        print(df_test[['Sentences','word_count']].head())
        
        df_test['char_count'] = df_test['Sentences'].str.len() ## this also includes spaces
        print(df_test[['Sentences','char_count']].head())
        
        from collections import Counter
        unique_vocab_test = len(Counter(" ".join(df_test['Sentences'].str.lower().values.tolist()).split(" ")).items())
        
        df_stat_test = df_test[['word_count', 'char_count']].agg(['sum','mean'])
        
        
        print("=========== Dataset Test Stat ===========")
        print(df_stat_test)
        print("Unique Vocab:" + str(unique_vocab_test))
        print(top_words_test.head(10))
        print("=========== Dataset Test Stat ===========")
        
        
        
        print("=========== Dataset Test ===========")
        print(df_test.head())
        print(len(df_test))
        print("=========== Dataset Test ===========")
        
        print("\n")
        
  
        print("=========== Labels ===========")
        testcomments_labels = df_test[['غصہ',"نفرت","خوف","اداسی","حیرت","خوشی"]]
        print(testcomments_labels.head())
        print(testcomments_labels.shape)
        print("=========== Labels ===========")
        print("\n")

        
        
        keywords_dictionary = []
        sentences_corpus = []
        

        #train data load
        for index,row in df_train.iterrows():
                text = str(row['Sentences'])               
                sentences_corpus.append(text)
                list_of_words = text.split(" ")
                keywords_dictionary.append(list_of_words)
            
        
        #test data load
        for index,row in df_test.iterrows():
            text = str(row['Sentences'])
            sentences_corpus.append(text)
            list_of_words = text.split(" ")
            keywords_dictionary.append(list_of_words)


        print("=========== Keywords and Sentences ===========")
        print(keywords_dictionary[0])
        print(sentences_corpus[0])
        print("=========== Keywords and Sentences ===========")
        print("\n")
        
        
     
              
        
     #%%   
        vocab = []
        for kl in keywords_dictionary: 
            for w in kl:
                vocab.append(str(w))
        
        
        
        corpus = []
        for kl in sentences_corpus: 
            corpus.append(''.join(kl))
            
        print("\n")
        
        print("=========== Vocab Length ===========")
        print(len(vocab))
        print("=========== Vocab Length ===========")
        
        if words:
            vectorizer = CountVectorizer(ngram_range=_ngram_range, max_features=_max_features)
            Count_Vect = vectorizer.fit_transform(corpus)
        else:
            vectorizer = CountVectorizer(ngram_range=_ngram_range, token_pattern = r"(?u)\b\w+\b",  analyzer='char')
            Count_Vect = vectorizer.fit_transform(corpus)
        
        
        tfidf_transformer=TfidfTransformer(smooth_idf=True,use_idf=True)
        tfidf_transformer.fit(Count_Vect)
        
        df_idf = pd.DataFrame(tfidf_transformer.idf_, index=vectorizer.get_feature_names(),columns=["idf_weights"])
        count_vector=vectorizer.transform(corpus)
        
        tf_idf_vector = tfidf_transformer.transform(count_vector)         
        feature_names = vectorizer.get_feature_names()         
        
        first_document_vector= tf_idf_vector[0]
        df = pd.DataFrame(first_document_vector.T.todense(), index=feature_names, columns=["tfidf"]).sort_values(by=["tfidf"],ascending=False)
        #df = df.sort_values(by=["tfidf"],ascending=False)
        
        
        
        
        print("=========== TF-IDF ===========")
        print(df.head(10))
        #print(df.sort_values(by=["tfidf"],ascending=False))
        print("=========== TF-IDF ===========")
        
        X = tf_idf_vector.toarray()
        #X = tf_idf_vector
        print(X.shape)
        

        #write features
        tf_idf_features = df.index.tolist()
        arf_feat = []
        features_cols= []
        for f in tf_idf_features[0:_max_features]:
            features_cols.append(f)
            arf_feat.append("@attribute " + "\'" + f + "\'" + " numeric")
            
        print(len(features_cols))
            
        
        #write classes
        arf_lbl = []
        lc = ['anger','disgust','fear','sadness','surprise','happiness']
        for l in lc:
            #features_cols.append(l)   
            arf_lbl.append("@attribute " +  l +"_class" + " {0,1}")    


        #df_features = pd.DataFrame(X[0:len(X),0:_max_features])
        #df_features = pd.DataFrame(X[0: X.shape[0] ,0:_max_features])
        
        
        #train file features
        df_features = pd.DataFrame(X[0: df_train.shape[0] , 0:_max_features])
        df_features.columns = features_cols
        df_features.dropna()
        comments_labels.dropna()
        
        #it is important to reset index in Urdu
        df_features.reset_index(drop=True, inplace=True)
        comments_labels.reset_index(drop=True, inplace=True)
        
        print("=========== Features Shape ===========")
        print(df_features.shape)
        print(comments_labels.shape)
        print(df_features.head())
        print("=========== Features Shape ===========")
        
        

               
        #frames = [df_features, comments_labels]
        frames = [comments_labels,df_features]
        df_attributes = pd.concat(frames, axis=1, sort=False)
        print(df_attributes.head())
        print(df_attributes.shape)
        df_attributes.reset_index(drop=True, inplace=True)
        df_attributes.to_csv(r"C:\Emotion_Urdu\Dataset\check.csv", sep=',', encoding = "utf-8-sig", index=False)
        
        attributes  = []
        attributes.append("@relation 'EMOTION: -C 6'")
        attributes  = attributes + arf_lbl + arf_feat 
        attributes.append("@data")
        
        
        with open(r"C:\Emotion_Urdu\Dataset\features/emtion_dataset_" + str(_ngram_range[0]) + "_gram_" + str(_max_features) + "_features_train" + ".arff", "w", encoding='utf-8') as f:
            for item in attributes:
                f.write("%s\n" % item)
            
            for index,row in df_attributes.iterrows():
                values = df_attributes.iloc[index]
                rows_data = []
                new_val = "" 
                for i,val in enumerate(values):                   
                    if val > 0:
                        new_val += str(i) + " " + str("1") + ","
                        rows_data.append(new_val)
            #    
                new_val = new_val[:-1] #remove last character
                new_val = "{" + new_val + "}" 
                f.write(new_val)
                f.write("\n")
                #print(new_val)
            #   if index ==30:
            #        break
            #sparse matrix data
            #f.write(df_attributes.to_string(header = False, index = False))
            #save without sparse
        print("File Saved!") 
        print("----------------------------------------------") 
        
        
        test_difference = X.shape[0] - df_train.shape[0]
        #print(test_difference)
        test_size = df_train.shape[0] + test_difference
        #print(test_size)
        #test file features
        df_test_features = pd.DataFrame(X[df_train.shape[0]:  test_size ,0:_max_features])
        
        print("Shape:" + str(df_test_features.shape))
        print(df_test_features.head())

        df_test_features.columns = features_cols
        
        #it is important to reset index in Urdu
        df_test_features.reset_index(drop=True, inplace=True)
        testcomments_labels.reset_index(drop=True, inplace=True)

               
        #frames = [df_features, comments_labels]
        frames_test = [testcomments_labels,df_test_features]
                
        df_attributes_test = pd.concat(frames_test, axis=1, sort=False)
        df_attributes_test.reset_index(drop=True, inplace=True)
        print(df_attributes_test.head())
        print("Shape:" + str(df_attributes_test.shape))


        attributes  = []
        attributes.append("@relation 'EMOTION: -C 6'")
        attributes  = attributes + arf_lbl + arf_feat 
        attributes.append("@data")
        
        

        
        with open(r"C:\Emotion_Urdu\Dataset\features/emtion_dataset_" + str(_ngram_range[0]) + "_gram_" + str(_max_features) + "_features_test" + ".arff", "w", encoding = "utf-8") as f:
            for item in attributes:
                f.write("%s\n" % item)
            print(df_attributes_test.shape)
            for index,row in df_attributes_test.iterrows():
                values = df_attributes_test.iloc[index]
                rows_data = []
                new_val = "" 
                for i,val in enumerate(values):                   
                    if val > 0:
                        new_val += str(i) + " " + str("1") + ","
                        rows_data.append(new_val)
            #    
                new_val = new_val[:-1] #remove last character
                new_val = "{" + new_val + "}" 
                f.write(new_val)
                f.write("\n")
        print("File Saved!") 
        
        
        
        
        
      